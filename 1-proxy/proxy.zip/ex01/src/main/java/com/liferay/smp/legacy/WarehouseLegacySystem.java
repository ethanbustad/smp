package com.liferay.smp.legacy;

public interface WarehouseLegacySystem {

	public long getProductInventory(long productId);
}