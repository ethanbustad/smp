package com.liferay.smp.persistence.db;

public class DataSourceImpl implements DataSource {

	@Override
	public String[] getData(String query) {
		return null;
	}
}