package com.liferay.smp.persistence.db;

public interface DataSource {

	public String[] getData(String query);
}