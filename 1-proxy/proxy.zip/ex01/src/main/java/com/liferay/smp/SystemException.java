package com.liferay.smp;

public class SystemException extends Exception {

	private static final long serialVersionUID = 1L;
}