package com.liferay.smp.audit;

/**
 * Do NOT modify.
 */
public class AuditContextFactoryImpl implements AuditContextFactory {

	@Override
	public AuditContext createAuditContext() {
		return null;
	}
}