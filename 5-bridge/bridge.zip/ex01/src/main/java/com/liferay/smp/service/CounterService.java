package com.liferay.smp.service;

public interface CounterService {

	public long increment();
}