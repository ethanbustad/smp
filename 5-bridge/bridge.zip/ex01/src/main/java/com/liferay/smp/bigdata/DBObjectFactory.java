package com.liferay.smp.bigdata;

public interface DBObjectFactory {

	public DBObject createDBObject();
}