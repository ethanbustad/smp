package com.liferay.smp.io;

import com.liferay.smp.IOException;

public class PrintWriterImpl implements PrintWriter {

	@Override
	public void open(String file) throws IOException {
	}

	@Override
	public void println(String line) throws IOException {
	}

	@Override
	public void close() throws IOException {
	}
}