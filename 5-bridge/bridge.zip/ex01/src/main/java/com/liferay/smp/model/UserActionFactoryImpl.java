package com.liferay.smp.model;

public class UserActionFactoryImpl implements UserActionFactory {

	@Override
	public UserAction createUserAction() {
		return null;
	}
}