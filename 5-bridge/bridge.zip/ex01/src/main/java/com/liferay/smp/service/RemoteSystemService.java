package com.liferay.smp.service;

public interface RemoteSystemService {

	public void checkSystemHealth();
}