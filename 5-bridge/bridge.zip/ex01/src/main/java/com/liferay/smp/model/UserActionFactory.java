package com.liferay.smp.model;

public interface UserActionFactory {

	public UserAction createUserAction();
}