package com.liferay.smp.bigdata;

public class DBObjectFactoryImpl implements DBObjectFactory {

	@Override
	public DBObject createDBObject() {
		return null;
	}
}