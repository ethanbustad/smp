package com.liferay.smp;

public class MongoException extends Exception {
	private static final long serialVersionUID = 1L;
}