package com.liferay.smp.event.when.model;

public enum DayOfWeek {
	MON, TUES, WED, THURS, FRI, SAT, SUN
}