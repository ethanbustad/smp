package com.liferay.smp.service.impl;

import com.liferay.smp.event.when.model.EventTime;
import com.liferay.smp.event.where.model.OnlineConference;
import com.liferay.smp.service.WebExMeetingService;

/**
 * Do not modify.  This is merely a stub.
 */
public class WebExMeetingServiceImpl implements WebExMeetingService {

	@Override
	public OnlineConference createNewConference(EventTime eventTime) {
		return null;
	}
}