package com.liferay.smp.event.where.model;

public interface OnlineConference extends Location {

	public void setURL(String url);
	public void setRoomToken(String roomToken);
}