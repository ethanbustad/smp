package com.liferay.smp.service.impl;

import com.liferay.smp.event.when.model.EventTime;
import com.liferay.smp.event.where.model.PhoneConference;
import com.liferay.smp.service.PhoneConferenceService;

/**
 * Do not modify.  This is merely a stub.
 */
public class PhoneConferenceServiceImpl implements PhoneConferenceService {

	@Override
	public PhoneConference createNewConference(EventTime eventTime) {
		return null;
	}
}