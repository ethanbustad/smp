package com.liferay.smp.service.impl;

import com.liferay.smp.event.when.model.EventTime;
import com.liferay.smp.event.where.model.MeetingRoom;
import com.liferay.smp.service.MeetingRoomSchedulingService;

/**
 * Do not modify.  This is merely a stub.
 */
public class MeetingRoomSchedulingServiceImpl implements
		MeetingRoomSchedulingService {

	@Override
	public MeetingRoom bookARoom(EventTime eventTime, int numberOfParticipants) {
		return null;
	}
}