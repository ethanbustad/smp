package com.liferay.smp.model;

import java.util.ArrayList;
import java.util.List;

import com.liferay.smp.IllegalOperationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderImpl implements OrderObservable {

	protected List<OrderObserver> orderObservers;

	private List<Product> products;
	private Status status = Status.NEW;
	private long customerId;

	@Override
	public void confirm() throws IllegalOperationException {
		_logger.debug("confirming order");

		if (status.getId() >= Status.CONFIRMED.getId()) {
			throw new IllegalOperationException();
		}
		status = Status.CONFIRMED;

		notifyObservers();
	}

	@Override
	public void delete() throws IllegalOperationException {
		_logger.debug("deleting order");

		if (status.getId() > Status.CONFIRMED.getId()) {
			throw new IllegalOperationException();
		}
		status = Status.DELETED;

		notifyObservers();
	}

	@Override
	public List<Product> getProducts() {
		return products;
	}

	@Override
	public Status getOrderStatus() {
		return status;
	}

	@Override
	public long getCustomerId() {
		return customerId;
	}

	public void addProduct(Product product) throws IllegalOperationException {
		_logger.debug("adding product to order: " + product.getName());

		if (status.getId() >= Status.CONFIRMED.getId()) {
			throw new IllegalOperationException();
		}

		if (products == null) {
			products = new ArrayList<Product>();
		}

		products.add(product);

		notifyObservers();
	}

	@Override
	public void addOrderObserver(OrderObserver orderObserver) {
		orderObservers.add(orderObserver);
	}

	public List<OrderObserver> getOrderObservers() {
		return orderObservers;
	}

	@Override
	public void notifyObservers() {
		for (OrderObserver observer : orderObservers) {
			_logger.debug("notifying observer: " + observer.getClass().getName());

			observer.handleUpdate(this);
		}
	}

	@Override
	public void removeOrderObserver(OrderObserver orderObserver) {
		orderObservers.remove(orderObserver);
	}

	public void setOrderObservers(List<OrderObserver> orderObservers) {
		this.orderObservers = orderObservers;
	}

	private Logger _logger = LoggerFactory.getLogger(this.getClass());
}