package com.liferay.smp.model;

public interface OrderObservable extends Order {
	public void addOrderObserver(OrderObserver orderObserver);
	public void removeOrderObserver(OrderObserver orderObserver);
	public void notifyObservers();
}
