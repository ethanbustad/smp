package com.liferay.smp.service.impl;

import com.liferay.smp.model.Order;
import com.liferay.smp.service.AccountingService;

public class AccountingServiceImpl implements AccountingService {

	@Override
	public void processPayment(Order order) {
	}

	@Override
	public void refundCustomer(Order order) {
	}
}