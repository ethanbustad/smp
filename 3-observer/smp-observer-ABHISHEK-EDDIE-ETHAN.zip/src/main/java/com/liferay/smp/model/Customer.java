package com.liferay.smp.model;

public interface Customer {

}
