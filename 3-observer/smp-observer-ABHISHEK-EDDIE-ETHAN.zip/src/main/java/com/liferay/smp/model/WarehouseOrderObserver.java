package com.liferay.smp.model;

import com.liferay.smp.service.WarehouseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WarehouseOrderObserver implements OrderObserver {

	WarehouseService warehouseService;

	@Override
	public void handleUpdate(Order order) {
		_logger.debug("fulfilling order");

		warehouseService.fulfillOrder(order);
	}

	public void setWarehouseService(WarehouseService warehouseService) {
		this.warehouseService = warehouseService;
	}

	public WarehouseService getWarehouseService() {
		return warehouseService;
	}

	private Logger _logger = LoggerFactory.getLogger(this.getClass());

}
