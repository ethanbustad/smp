package com.liferay.smp.model;

import com.liferay.smp.service.AccountingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AccountingOrderObserver implements OrderObserver {

	private AccountingService accountingService;

	@Override
	public void handleUpdate(Order order) {
		_logger.debug("processing payment");

		accountingService.processPayment(order);
	}

	public void setAccountingService(AccountingService accountingService) {
		this.accountingService = accountingService;
	}

	public AccountingService getAccountingService() {
		return accountingService;
	}

	private Logger _logger = LoggerFactory.getLogger(this.getClass());


}
