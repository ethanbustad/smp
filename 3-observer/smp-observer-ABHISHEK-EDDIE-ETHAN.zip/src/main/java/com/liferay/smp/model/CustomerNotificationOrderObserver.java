package com.liferay.smp.model;

import com.liferay.smp.service.CustomerNotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomerNotificationOrderObserver implements OrderObserver {

	private CustomerNotificationService customerNotificationService;

	@Override
	public void handleUpdate(Order order) {
		_logger.debug("sending order notification");

		customerNotificationService.sendOrderNotification(order);
	}

	public void setCustomerNotificationService(CustomerNotificationService customerNotificationService) {
		this.customerNotificationService = customerNotificationService;
	}

	public CustomerNotificationService getCustomerNotificationService() {
		return customerNotificationService;
	}

	private Logger _logger = LoggerFactory.getLogger(this.getClass());

}
