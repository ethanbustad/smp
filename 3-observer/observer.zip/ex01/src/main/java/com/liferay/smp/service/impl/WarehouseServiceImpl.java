package com.liferay.smp.service.impl;

import com.liferay.smp.model.Order;
import com.liferay.smp.service.WarehouseService;

public class WarehouseServiceImpl implements WarehouseService {

	@Override
	public void fulfillOrder(Order order) {
	}
}