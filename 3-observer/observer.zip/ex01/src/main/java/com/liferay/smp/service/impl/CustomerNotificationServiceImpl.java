package com.liferay.smp.service.impl;

import com.liferay.smp.model.Customer;
import com.liferay.smp.model.Order;
import com.liferay.smp.service.CustomerNotificationService;

public class CustomerNotificationServiceImpl implements
		CustomerNotificationService {

	@Override
	public void sendOrderNotification(Order order) {
	}

	@Override
	public void sendProfileUpdateNotification(Customer customer) {
	}
}